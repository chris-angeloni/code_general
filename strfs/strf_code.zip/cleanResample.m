function Y = cleanResample(X,rin,rout)

% function Y = cleanResample(X,rin,rout)
% resample to preserve "hard" stimulus boundaries by using nearest
% neighbor interpolation

% transpose for speed??
X = X';

Y = zeros(size(X,2),size(X,1)*(rin/rout));
xq = linspace(1,length(X),length(X) * (rin/rout));
for i = 1:size(X,2)
    Y(i,:) = interp1(X(:,i),xq,'nearest');
end