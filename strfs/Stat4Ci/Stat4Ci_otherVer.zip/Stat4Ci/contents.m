Contents

AGBTSD04.cid			ZTransSCi.m			initScreen.m
CheckResp.m			an_image_list.txt		loadListOfImages.m
Ci2cIm.m			bubbles_threshold.m		locationNoise.m
CiVol.m				buildCi.m			makeCid.m
DisplayRes.m			cIm2Ci.m			makeData.m
ExpectedNoise.m			codeWorsley.m			manual
ExpectedSCi.m			dataStat.m			old
Gosselin & Schyns (2001)	demo.cid			pyramidNoise.m
HalfMax.m			demo.mat			readCid.m
NEW_TEST.M			demo.pcid			showNrec.m
SmoothCi.m			demoVSS.m			stat_threshold.m
StatThresh.m			initQuest.m			whiteNoise.m


%  Ci2cIm   Transforms a Ci classification image (hrCi) into a uint8 color
%           image (cIm). The color image can then be saved in your favorite image format without loss of information (e.g., TIF). 
% cIm2Ci Transforms a uint8 color image (cIm) into a 2D high-res (24 bits) classification image (hrCi).
 